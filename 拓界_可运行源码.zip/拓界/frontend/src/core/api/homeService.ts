import type { ModuleManifest, UserProfile } from '../types'
import { apiRequest, canUseOfflineDemo } from './apiClient'

export interface HomeData {
  profile: UserProfile
  currentGoal: string
  recentActivity: string
  modules: ModuleManifest[]
}

const fallback: HomeData = {
  profile: { id: 'demo-user', name: '林澈', goals: ['独立完成网络服务部署'] },
  currentGoal: '独立完成一个可复现的网络服务部署',
  recentActivity: '今天更新了 TCP/IP 的掌握状态',
  modules: [
    {
      id: 'ability-growth',
      title: '能力成长',
      description: '把经验转成能力图谱，找到下一步',
      route: '/ability',
      status: 'ready',
      updatedAt: '今天 21:32',
    },
    {
      id: 'decision-sandbox',
      title: '决策沙盒',
      description: '改变现实条件，比较不同选择的代价',
      route: '/decision',
      status: 'ready',
      updatedAt: '可使用',
    },
    {
      id: 'module3',
      title: '实践验证与复盘',
      description: '核对成果证据，记录实际投入与补验变化',
      route: '/module3',
      status: 'prototype',
      updatedAt: '已可演示',
    },
    {
      id: 'module4',
      title: '职业规划',
      description: '匹配岗位、分析 JD、规划能力提升',
      route: '/module4/match',
      status: 'prototype',
      updatedAt: '演示岗位库',
    },
  ],
}

// The registered entries also support navigation before personal data loads.
export const defaultModuleManifests: readonly ModuleManifest[] = fallback.modules

export const homeService = {
  async getHome(): Promise<HomeData> {
    try {
      return await apiRequest<HomeData>('/home')
    } catch (cause) {
      if (!canUseOfflineDemo(cause)) throw cause
      return structuredClone(fallback)
    }
  },
}
