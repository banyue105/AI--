<script setup lang="ts">
import { ref, watch } from 'vue'
import { RouterView, useRoute } from 'vue-router'
import AppNavigation from './app/AppNavigation.vue'

const route = useRoute()
const transitionName = ref('page-forward')
const pageOrder = (path: string) => {
  if (path === '/') return 0
  if (path.startsWith('/ability')) return 1
  if (path.startsWith('/decision')) return 2
  if (path.startsWith('/module3')) return 3
  if (path.startsWith('/module4')) return 4
  return 0
}
watch(() => route.fullPath, (to, from) => {
  transitionName.value = pageOrder(to) >= pageOrder(from) ? 'page-forward' : 'page-back'
})
</script>

<template>
  <AppNavigation />
  <RouterView v-slot="{ Component, route }">
    <Transition :name="transitionName" mode="out-in">
      <component :is="Component" :key="route.fullPath" />
    </Transition>
  </RouterView>
</template>
